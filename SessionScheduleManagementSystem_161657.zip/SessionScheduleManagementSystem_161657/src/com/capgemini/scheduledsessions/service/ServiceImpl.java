package com.capgemini.scheduledsessions.service;

import java.util.ArrayList; 
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.scheduledsessions.dao.IDao;
import com.capgemini.scheduledsessions.entity.ScheduledEntity;
import com.capgemini.scheduledsessions.exception.SessionException;
import com.capgemini.scheduledsessions.model.ScheduledSession;

@Service
@Transactional
public class ServiceImpl implements IService {
	
	@Autowired
	private IDao dao;

	@Override
	public List<ScheduledSession> getDetails() throws SessionException {
		List<ScheduledEntity> sessions=dao.getDetails();
		try{
		if(sessions !=null) {
			List<ScheduledSession> sessionList=new ArrayList<>();				
			populateCustomerList(sessionList,sessions);
			return sessionList;
		}else{
			throw new SessionException("Session List is empty");
		}
		}catch(SessionException e) {
			
			throw new SessionException(e.getMessage());
		}
	}
	
	private void populateCustomerList(List<ScheduledSession> sessionsList, List<ScheduledEntity> sessions) {
		Iterator<ScheduledEntity> iterator= sessions.iterator();		
		while(iterator.hasNext()) {
			ScheduledSession sessionList=new ScheduledSession();
			populateCustomer(sessionList,iterator.next());
			sessionsList.add(sessionList);		
		}
		
	}

	private void populateCustomer(ScheduledSession sessions, ScheduledEntity next) {
		sessions.setName(next.getName());
		sessions.setDuration(next.getDuration());
		sessions.setFaculty(next.getFaculty());
		sessions.setMode1(next.getMode1());
	}

}
