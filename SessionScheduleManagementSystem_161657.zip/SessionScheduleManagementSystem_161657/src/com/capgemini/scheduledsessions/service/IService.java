package com.capgemini.scheduledsessions.service;

import java.util.List; 




import com.capgemini.scheduledsessions.exception.SessionException;
import com.capgemini.scheduledsessions.model.ScheduledSession;

public interface IService {
	List<ScheduledSession> getDetails() throws SessionException;

}
