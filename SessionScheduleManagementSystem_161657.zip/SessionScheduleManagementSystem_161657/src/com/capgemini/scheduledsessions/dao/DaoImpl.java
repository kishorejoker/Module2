package com.capgemini.scheduledsessions.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.scheduledsessions.entity.ScheduledEntity;
import com.capgemini.scheduledsessions.exception.SessionException;

@Repository
@Transactional
public class DaoImpl implements IDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<ScheduledEntity> getDetails() throws SessionException {
		
		String sql="From ScheduledEntity";
		try {
			
			Query query=entityManager.createQuery(sql);
			List<ScheduledEntity> sessions=query.getResultList();			
			return sessions;
			
	}catch(Exception e){
		throw new SessionException("Query can't Execute!!!");
	}

}
}
