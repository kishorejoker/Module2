package com.capgemini.scheduledsessions.dao;

import java.util.List; 

import com.capgemini.scheduledsessions.entity.ScheduledEntity;
import com.capgemini.scheduledsessions.exception.SessionException;

public interface IDao {
	List<ScheduledEntity> getDetails() throws SessionException ;

}
