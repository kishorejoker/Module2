package com.capgemini.scheduledsessions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.scheduledsessions.exception.SessionException;
import com.capgemini.scheduledsessions.model.ScheduledSession;
import com.capgemini.scheduledsessions.service.IService;

@Controller
@RequestMapping(value="/")
public class SessionController {
	
	@Autowired
	private IService service;
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public ModelAndView getDetails() throws SessionException {
		List<ScheduledSession> sessionList=service.getDetails();
		if(sessionList.size()!=0) {				
			return new ModelAndView("ScheduledSessions","sessionList",sessionList);
		}else {
			throw new SessionException("ScheduledSessions Cannot Found!!!");
		}

}
}
